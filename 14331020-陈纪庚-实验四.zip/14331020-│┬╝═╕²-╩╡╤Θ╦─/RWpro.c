#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h> 
#include <semaphore.h>
#include <signal.h>
#include <string.h>

pthread_mutex_t mutex ;

sem_t write;
int read_count;

struct info
{
	int start_time;
	int end_time;
	int id;
};
void * Reader(void * param) {
	struct info * d = (struct info*)param;
	int start_time = d->start_time;
	int end_time = d->end_time;
	int id = d->id;
	// printf("%d\n", id);
	sleep(start_time);
	pthread_mutex_lock(&mutex);
	read_count++;
	// printf("%d\n", read_count);

	printf("id%d Reader begin to request to read\n", id);
	if (read_count == 1) {
		sem_wait(&write);
	}
	printf("id%d Reader begin to read\n", id);
	pthread_mutex_unlock(&mutex);
	sleep(end_time);
	pthread_mutex_lock(&mutex);
	read_count--;
	if (read_count == 0) {
		sem_post(&write);
	}
	printf("id%d Reader end reading\n", id);
	pthread_mutex_unlock(&mutex);
}
void * Writer(void * param) {
	struct info * d = (struct info*)param;
	int start_time = d->start_time;
	int end_time = d->end_time;
	int id = d->id;
	sleep(start_time);
	printf("id%d Writer begin to request to write\n", id);
	sem_wait(&write);
	printf("id%d Writer begin to write\n", id);
	sleep(end_time);
	sem_post(&write);
	printf("id%d Writer end writing\n", id);
}
int main() {
	pthread_mutex_init(&mutex,NULL);
	sem_init(&write,0,1);
	int i = 0;
	int num, start_time, end_time, id;
	char R_W;
	pthread_t Writer_n[100];
	pthread_t Reader_n[100];
	pthread_attr_t attr, attr1;
  pthread_attr_init(&attr);
  pthread_attr_init(&attr1);
	FILE *fp;
	int read_num = 0;
	int write_num = 0;
	fp=fopen("test.txt", "r" );//文件名你自己去指定，这里暂用test.txt
	if ( fp == NULL )
	{
		printf("open file error\n");
		return -1;
	}
	while( !feof(fp) )
	{
		int i = 0;
		char str[1024];
		char *p;
		if ( fgets(str , sizeof(str) , fp)==NULL )
		break ;
		p=strtok( str , " " );
		while (p)
		{
			i++;
			if (i == 1) {
				id = atoi(p);
			}
			else if (i == 3) {
				start_time = atoi(p);
			}
			else if (i == 2) {
				R_W = *p;
			}
			else if (i == 4) {
				end_time = atoi(p);
				struct info * data = (struct info * )malloc(sizeof(struct info));
				data->start_time = start_time;
				data->end_time = end_time;
				data->id = id;
	 			i = 0;
	 			if (R_W == 'R') {
	 				printf("id%d Reader is created\n", id);
					pthread_create(&Reader_n[read_num++],&attr,Reader, (void *)data);
	 			}
				else {
					printf("id%d Writer is created\n", id);
					pthread_create(&Writer_n[write_num++],&attr1,Writer, (void *)data);
				}
			}
			p=strtok(NULL," "); 
		}
	}
	fclose(fp);
	i = 0;
	for (; i < read_num; i++) {
		pthread_join(Reader_n[i], NULL);
	}
	i = 0;
	for (; i < write_num; i++) {
		pthread_join(Writer_n[i], NULL);
	}
	printf("end\n");
}