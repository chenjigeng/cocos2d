#include<iostream>
#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>
#include<semaphore.h>
#include<unistd.h>
#include<list>

using namespace std;

sem_t x_sem;

int x_count = 0;

struct InterfaceModule {
	int next_count;
	sem_t mutex;
	sem_t next;
	sem_t self[5];
};

void menter(InterfaceModule &IM) {
	sem_wait(&IM.mutex);          
}

void mleave(InterfaceModule &IM) {
    if(IM.next_count>0)       
		sem_post(&IM.next);                   
    else
		sem_post(&IM.mutex);     
}

void mwait(sem_t &x_sem, int &x_count, InterfaceModule &IM) {
	x_count++;  
	if(IM.next_count>0)   
        sem_post(&IM.next);   
  	else 
        sem_post(&IM.mutex);  
  	sem_wait(&x_sem);         
  	x_count--;        
}

void msignal(sem_t &x_sem, int &x_count, InterfaceModule &IM) {
	if(x_count>0) {  
		IM.next_count++;  
	    sem_post(&x_sem);         
	    sem_wait(&IM.next);        
	    IM.next_count--;
	}
}

enum states {thinking,hungry,eating};

class dining_philosophers {
 public:
	static states state[5];
	static int self_count[5];
	static InterfaceModule IM;
	
	static void pickup(int i) {       //i=0,1,2,..,4
    	menter(IM);
		state[i]=hungry;
		printf("The %d philosopher is hungry\n", i);
		test(i);
		if(state[i]!=eating) {
	    	mwait(IM.self[i],self_count[i],IM);
	    }
     mleave(IM);
	}
	
	static void putdown(int i) {       //i=0,1,2,..,4
    	menter(IM);
    	state[i]=thinking;
    	printf("The %d philosopher put down the chock\n", i);
    	test((i+4)%5);
    	test((i+1)%5);
    	mleave(IM);
	}
	
	static void test(int k) {       //k=0,1,...,4
		if((state[(k+4)%5]!=eating)&&(state[k]==hungry)
		&&(state[(k+1)%5]!=eating)) {
			state[k]=eating;
			printf("The %d philosopher is eating\n", k);
			msignal(IM.self[k],self_count[k],IM);
	 	}
    }
    
};

states dining_philosophers::state[5] = {thinking};
int dining_philosophers::self_count[5] = { 0 };
InterfaceModule dining_philosophers::IM = {0};
void think(int id) {
	int sleepTime = rand()%5 + 1;
	printf("The %d philosopher is thinking %ds\n", id, sleepTime);
	sleep(sleepTime);
}
void * phil(void * data) {
	while(true) {
		int * id = (int *)data;
		if (dining_philosophers::state[*id] == thinking)
			think(*id);
		dining_philosophers::pickup(*id);
		if (dining_philosophers::state[*id] == eating) {
			sleep(rand() % 5);
			dining_philosophers::putdown(*id);
		}
	}
}
int main() {
	int i = 0;
	for (; i < 5; i++) {
		sem_init(&dining_philosophers::IM.self[i], 0, 1);
	}
	sem_init(&dining_philosophers::IM.mutex, 0, 1);
	sem_init(&dining_philosophers::IM.next, 0, 0);
	sem_init(&x_sem, 0, 0);
	pthread_t tids[5];
	pthread_attr_t attr;
	i = 0;
	pthread_attr_init(&attr);
	for (; i <= 4; i++) {
		int * j = new int(i); 
		pthread_create(&tids[i], &attr, phil, (void *) j);
	}
	for (i = 0; i <=4; i++) {
		pthread_join(tids[i], NULL);
	}
	
}
