#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h> 
#include <semaphore.h>
#include <signal.h>
#include <unistd.h>

#define BUFFER_SIZE 5
typedef int buffer_item;
pthread_mutex_t mutex ;

sem_t empty,full;

buffer_item buffer[BUFFER_SIZE]={-1,-1,-1,-1,-1};
int count = 0;

int insert_item(buffer_item item) {
    sem_wait(&empty);
    pthread_mutex_lock(&mutex);
    int state = 0;
    int i = 0;
    if(buffer[count]!=-1){
        state = 1;
		}
    else{
    	buffer[count] = item;
    	count = (count+1)%BUFFER_SIZE;
    }
    pthread_mutex_unlock(&mutex);
    sem_post(&full);
    if(state)
        return - 1;
    else
        return 0;
}
int remove_item(buffer_item *item){
    sem_wait(&full);
    pthread_mutex_lock(&mutex);
    int state = 0;
    if(count>0)
        count = count-1;
    else
        count = 4;
    if(buffer[count] != -1){
    	*item = buffer[count];
    	buffer[count] = -1;
    }
    else {
       state = 1;
    }
    pthread_mutex_unlock(&mutex);
    if (state) {
    	sem_post(&full);
    }
    else 
    	sem_post(&empty);
    if(state)
        return -1;
    else
        return 0;
}

void *producer(void *param){
    buffer_item randb;
    // signal(SIGQUIT, pthreadExit);
    srand((unsigned)time(NULL));
    while(1){
        randb = rand() % 10;
        sleep(rand()%2+1);
        printf("producer produced %d\n", randb);
        if(insert_item(randb)){
            printf("report error condition\n");
        }
    }
}

void *consumer(void *param){
    buffer_item randb;
    // signal(SIGQUIT, pthreadExit);
    srand((unsigned)time(NULL));
    while(1){
        sleep(rand()%2+1);
        if(remove_item(&randb))
            printf("report error condition\n");
        else {
            printf("consume consumed %d\n",randb);
        }
}}


int main(int argc,char *argv[])
{
	int sleep_time = atoi(argv[1]);
	int pro_num = atoi(argv[2]);
	int con_num = atoi(argv[3]);
    pthread_mutex_init(&mutex,NULL);
    sem_init(&empty,0,5);
    sem_init(&full,0,0);
    pthread_t ThreadsIdOfConsumer[100];
    pthread_t ThreadsIdOfProducer[100];
    pthread_attr_t ThreadHandleOfConsumer;
    pthread_attr_t ThreadHandleOfProducer;
    int Param = 10;
    pthread_attr_init(&ThreadHandleOfConsumer);
    pthread_attr_init(&ThreadHandleOfProducer);
    int i;
    for (i = 0; i < con_num; i++) {
    	pthread_create(&ThreadsIdOfConsumer[i],&ThreadHandleOfConsumer,consumer,NULL);
    }
    for (i = 0; i < pro_num; i++) {
    	pthread_create(&ThreadsIdOfProducer[i],&ThreadHandleOfProducer,producer,NULL);      
    }            
    sleep(sleep_time);
    for (i = 0; i < pro_num; i++) {
   		pthread_kill(ThreadsIdOfProducer[i], 0);
   	}
    for (i = 0; i < con_num; i++) {
    	pthread_kill(ThreadsIdOfConsumer[i], 0);
  	}
    return 0;
}


